(() => {
    document.addEventListener("DOMContentLoaded", () => {
        // js code here
    }
    );
})()